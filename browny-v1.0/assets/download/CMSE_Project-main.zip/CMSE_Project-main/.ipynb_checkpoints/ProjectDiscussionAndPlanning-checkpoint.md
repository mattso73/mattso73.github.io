Collaboration/Communication Discussion:
  Getting your work done on time. Being consistent
  Communicating.
  Being respectful.
  Being kind.
  Asking questions
  Communication via Imessage
  Meetings: As needed. Via Zoom

  Equal Contribution:
  Splitting up work evenly
  Explaining the changes that you have made
  Making sure everyone has a role

  Overall Goals:
  Predict the NFL MVP for 2024-2025.
  Thinking about positions.
  How should we value an MVP?
  What makes an MVP?
  DPOY?
  Rookie of the Year?

  Roles:
  In Progress
